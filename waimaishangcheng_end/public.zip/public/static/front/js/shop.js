(function($){
    //加载shop信息
    var shopId=$('.shop-name').attr('shopId');

    if(shopId){
        loadShopInfo(shopId);
    }
    //加载my信息 
    loadMyInfo(); 
})(jQuery);
//加载shop信息
function loadShopInfo(shopId){
    if(shopId){
        $.ajax({
            url:'http://www.takeout.com/v1/shopInfo/'+shopId,
            success:function ($res) {
               // console.log($res);
                if( $res.errcode== 0){
                    //shop_SaveValue("shopId",$res.data['shopId']);
                    shop_SaveValue("shopId",shopId);
                    shop_SaveValue("shopName",$res.data['shopName']);
                    shop_SaveValue("shopPhone",$res.data['shopPhone']);
                    shop_SaveValue("shopTip",$res.data['shopTip']);
                    shop_SaveValue("shopIcon",$res.data['shopIcon']);
                    shop_SaveValue("shopFloor",$res.data['shopFloor']);
                }
            },
            error:function () {
                //服务器异常时
                setTimeout("loadShopInfo('"+shopId+"')", 2000);//2秒后再请求一次
            }
        });
    }
}