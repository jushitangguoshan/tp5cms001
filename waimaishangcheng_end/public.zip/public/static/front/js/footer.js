
(function($) {
    $('.footer-content-weixing').hover(function() {
        $('.weixin-pic').show();
    }, function() {
        $('.weixin-pic').hide();
    });
})(jQuery);

 